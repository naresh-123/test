export class UserDefinedLabels {
    static flex_set =  22;
      static feildAppearance = 'legacy';
        static readonly floatLabel = 'auto'; 
        static readonly records_per_page = 10;
    }